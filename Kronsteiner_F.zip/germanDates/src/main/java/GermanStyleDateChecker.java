import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GermanStyleDateChecker {
    
    
    public static Matcher getMatcher(String dateString) {
        Pattern p = Pattern.compile("^((((0?[1-9]{1})|((1|2)[0-9])|(30))[\\.\\- ](0?[2469]|11)[\\.\\- ]((\\d\\d)|(19\\d\\d)|(20\\d\\d)))|(((0?[1-9]{1})|((1|2)[0-9])|(31))[\\.\\- ](0?[123568]|10|12)[\\.\\- ]((\\d\\d)|(19\\d\\d)|(20\\d\\d))))$");
        Matcher m = p.matcher(dateString);
        
        return m;
    }
}

//Extension for february |(((0?[1-9]{1})|(1[0-9])|(2[0-8]))[\.\- ](0?2)[\.\- ]((\d\d)|(19\d\d)|(20\d\d)))